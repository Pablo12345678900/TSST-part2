﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Net;
using System.Collections.Generic;
using Tools;
using System.Threading;
using static Tools.RoutingController;
using System.Linq;
using System.Globalization;

namespace Subnetwork
{
    public class StateObject
    {
        // Client  socket.  
        public Socket workSocket = null;

        // Size of receive buffer.  
        public const int BufferSize = 128;

        // Receive buffer.  
        public byte[] buffer = new byte[BufferSize];

        // Received data string.  
        public StringBuilder sb = new StringBuilder();
    }
    class Program
    {
        public static Subnet subnetwork = new Subnet();
        static void Main(string[] args)
        {
            try
            {
                subnetwork.readInfo(args[0]);
            }
            catch(Exception e)
            {

            }
            byte[] buffer = new byte[128];
            subnetwork.subClientToCloud.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), (int)subnetwork.cloudPort));
            subnetwork.subClientToCloud.Send(Encoding.ASCII.GetBytes("First Message " + subnetwork.ip.ToString()));
            subnetwork.subClientToCloud.Receive(buffer);
            List<ushort> ports = subnetwork.givePorts(buffer);
            /*foreach(var port in ports)
            {
                LinkResourceManager link = new LinkResourceManager(port);
                link.IPofNode = subnetwork.ip;
                subnetwork.lrms.Add(link);
            }*/
            // tworzenie interfaceów
            //1.znajdz min port
            //0ushort p = ushort.MaxValue;
            
            while(ports.Count>0)
            {
                ushort p = ushort.MaxValue;
                foreach (var port in ports)
                {
                    if (port < p)
                    {
                        p = port;
                    }
                }
                ports.Remove(p);
                foreach(var port in ports)
                {
                    if ((port - p) == 1)
                    { 
                        Interface inter = new Interface(subnetwork.ip, p);
                        LinkResourceManager link = new LinkResourceManager(p);
                        LinkResourceManager link1 = new LinkResourceManager(port);
                        link1.IPofNode = subnetwork.ip;
                        link.IPofNode = subnetwork.ip;
                        subnetwork.lrmForDomain.Add(link);
                        //subnetwork.lrms
                        subnetwork.interfaces.Add(inter);
                        ports.Remove(port);
                        // p = port;
                        break;
                    }
                }
            }
            List<byte> bufferLRM = new List<byte>();
            bufferLRM.AddRange(Encoding.ASCII.GetBytes("SUBNETWORK-callin " + subnetwork.ip.ToString() + " " + subnetwork.port + " "));
           // int i = 0;
            foreach (LinkResourceManager lrm in subnetwork.lrmForDomain)
            {
                //bufferLRM.Add(0);
                bufferLRM.AddRange(lrm.convertToBytes());
              //  buffer2.AddRange(lrm.convertToBytes());
               // Console.WriteLine((ushort)((buffer2[i + 1] << 8) + buffer2[i]));
               // i += 16;
            }
            subnetwork.subClient.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), (int)subnetwork.portDomain));

            subnetwork.subClient.Send(bufferLRM.ToArray());
            Thread thread = new Thread(WaitForData);
            thread.Start();
            subnetwork.subServer.Bind(new IPEndPoint(IPAddress.Parse("127.0.0.1"), (int)subnetwork.port));
           // subnetwork.subClient = new Socket(IPAddress.Parse("127.0.0.1").AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            subnetwork.subServer.Listen(50);
            //Console.WriteLine((int)subnetwork.portDomain + " " + (int)subnetwork.port);
            
            while(true)
            {
                subnetwork.subDone.Reset();
                subnetwork.subServer.BeginAccept(new AsyncCallback(AcceptCallBack), subnetwork.subServer);
                subnetwork.subDone.WaitOne();
            }
        }
        public static void AcceptCallBack(IAsyncResult asyncResult)
        {
            subnetwork.subDone.Set();
            Socket listener = (Socket)asyncResult.AsyncState;
            Socket handler = listener.EndAccept(asyncResult);
            StateObject stateObject = new StateObject();
            stateObject.workSocket = handler;

            handler.BeginReceive(stateObject.buffer, 0, stateObject.buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallBack), stateObject);

        }
        public static void ReceiveCallBack(IAsyncResult asyncResult)
        {
            StateObject state = (StateObject)asyncResult.AsyncState;
            Socket handler = state.workSocket; //socket of client
            int ReadBytes;
            try
            {
                ReadBytes = handler.EndReceive(asyncResult);

            }
            catch (Exception e)
            {
                if (subnetwork.CC.IPfromSocket.ContainsKey(handler))
                {


                    IPAddress dyingNode = subnetwork.CC.IPfromSocket[handler]; // router wysyła też swoje LRMy więc trzeba je dodać
                    Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                            System.Globalization.CultureInfo.InvariantCulture) + "] " + "Node: " + dyingNode.ToString() + " died [*].");
                    int index = -1;
                    for (int i = 0; i < subnetwork.RC.nodesToAlgorithm.Count(); i++)
                    {
                        if (subnetwork.RC.nodesToAlgorithm[i].Equals(dyingNode))
                        {
                            index = i;
                            break;
                        }
                    }
                    if (index >= 0)
                    {
                        //usuwamy martwy node z listy
                        subnetwork.RC.nodesToAlgorithm.RemoveAt(index);
                        //usuwamy lrmy w ktorych jest martwy node
                        bool flaga = true;
                        /*while (flaga)
                        {
                            index = -1;
                            for (int k = 0; k < domain.RC.lrms.Count(); k++)
                            {
                                if (k == domain.RC.lrms.Count() - 1)
                                {
                                    flaga = false;
                                }
                                if (domain.RC.lrms[k].IPofNode.Equals(dyingNode))
                                {
                                    index = k;
                                    break;
                                }
                            }
                            if (index >= 0) { domain.RC.lrms.RemoveAt(index); }

                        }*/
                        //wylaczamy kable
                        foreach (Cable c in subnetwork.RC.cables)
                        {
                            if (c.Node1.Equals(dyingNode) || c.Node2.Equals(dyingNode))
                            { c.stateOfCable = false; }
                        }

                        //sprawdzamy czy przez martwy node przechodzily polaczenia, jesli tak musimy je znow wyznaczyc


                        IPAddress source_add = IPAddress.Parse("0.0.0.0");
                        IPAddress dest_add = IPAddress.Parse("0.0.0.0");
                        int speed;

                        if (subnetwork.CC.Connections.Count > 0)
                        {
                            bool flaga2 = false;
                            //Console.WriteLine("Checkpoint 2");
                            flaga2 = false;
                            for (int i = 0; i < subnetwork.CC.Connections.Count(); i++)
                            {
                                for (int k = 0; k < subnetwork.CC.Connections[i].Path.Count(); k++)
                                {
                                    if (subnetwork.CC.Connections[i].Path[k].Equals(dyingNode))
                                    {
                                        source_add = subnetwork.CC.Connections[i].Path[0];
                                        dest_add = subnetwork.CC.Connections[i].Path[subnetwork.CC.Connections[i].Path.Count() - 1];
                                        speed = subnetwork.CC.Connections[i].speed;

                                        List<int> idxOfSlots = new List<int>();
                                        for (int j = 0; j < 10; j++)
                                        {
                                            if (subnetwork.CC.Connections[i].slots[j])
                                            {
                                                idxOfSlots.Add(j);

                                            }
                                        }

                                        //Console.WriteLine("Checkpoint pre REL");
                                        List<byte> bufferToSend = new List<byte>();
                                        int ct = 0;
                                        foreach (var cab in subnetwork.CC.Connections[i].nodeAndPortsOut)
                                        {
                                            if (!cab.Key.Equals(dyingNode))
                                            {
                                                bool flaga1 = false;
                                                Socket socket = subnetwork.CC.SocketfromIP[cab.Key];
                                               // Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                                                foreach (var cab1 in subnetwork.CC.Connections[i].nodeAndPortsIn)
                                                {
                                                    if (cab1.Key.Equals(cab.Key))
                                                    {
                                                        bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[0]));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[idxOfSlots.Count - 1]));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                                                        socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                        bufferToSend.Clear();
                                                        flaga1 = true;
                                                        break;
                                                    }
                                                }
                                                if (!flaga1)
                                                {
                                                    bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                                                    bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[0]));
                                                    bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[idxOfSlots.Count - 1]));
                                                    bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));

                                                    socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                    bufferToSend.Clear();
                                                    flaga1 = false;
                                                }
                                            }
                                        }


                                        foreach (Cable c in subnetwork.RC.cables)
                                        {
                                            if (c.Node1.Equals(dyingNode) || c.Node2.Equals(dyingNode))
                                            { c.stateOfCable = false; }
                                        }

                                        // Console.WriteLine("Checkpoint pre LRM");
                                        //czyszczenie lrmow w RC
                                        foreach (IPAddress ipadd in subnetwork.CC.Connections[i].Path)
                                        {
                                            if (subnetwork.CC.Connections[i].nodeAndPortsOut.ContainsKey(ipadd))
                                            {
                                                ushort portout = subnetwork.CC.Connections[i].nodeAndPortsOut[ipadd];

                                                foreach (LinkResourceManager l in subnetwork.RC.lrms)
                                                {
                                                    if (l.IPofNode.Equals(ipadd) && l.port.Equals(portout))
                                                    {
                                                        for (int bb = subnetwork.CC.Connections[i].startSlot; bb <= subnetwork.CC.Connections[i].lastSlot; bb++)
                                                        { l.slots[bb] = true; }
                                                    }
                                                }
                                            }
                                        }
                                        int startslot = subnetwork.CC.Connections[i].startSlot;
                                        int endslot = subnetwork.CC.Connections[i].lastSlot;
                                        int dlength = subnetwork.CC.Connections[i].lengthOfGivenDomain;
                                        subnetwork.CC.Connections.RemoveAt(i);
                                        flaga2 = true;
                                        ////wysylanie na nowo
                                        Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "Configurations cleared, recalculating path...");
                                        try
                                        {
                                            RoutingResult routingResult = subnetwork.RC.SubentDijkstraAlgorithm(source_add, dest_add, subnetwork.RC.cables, subnetwork.RC.lrms, speed, startslot, endslot, dlength);

                                            subnetwork.CC.Connections.Add(routingResult);
                                            //wymuszenie exception dla pustego
                                            if (routingResult.Equals(null)) { }
                                            List<int> idxOfSlots1 = new List<int>();
                                            for (int a = 0; a < 10; a++)
                                            {
                                                if (routingResult.slots[a])
                                                {
                                                    idxOfSlots1.Add(a);
                                                }
                                            }
                                            foreach (var node in routingResult.Path)
                                            {
                                                Console.WriteLine("Chosen node: " + node.ToString());
                                            }
                                            List<byte> bufferToSend1 = new List<byte>();
                                            foreach (var cab in routingResult.nodeAndPortsOut)
                                            {
                                                bool flaga3 = false;
                                                Socket socket = subnetwork.CC.SocketfromIP[cab.Key];
                                                Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                                                foreach (var cab1 in routingResult.nodeAndPortsIn)
                                                {
                                                    if (cab1.Key.Equals(cab.Key))
                                                    {
                                                        Console.WriteLine("Port in: " + cab1.Value);
                                                        bufferToSend1.AddRange(Encoding.ASCII.GetBytes("ACK"));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[0]));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[idxOfSlots1.Count - 1]));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(cab.Value));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(cab1.Value));
                                                        socket.BeginSend(bufferToSend1.ToArray(), 0, bufferToSend1.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                        bufferToSend1.Clear();
                                                        flaga3 = true;
                                                        break;
                                                    }
                                                }
                                                if (!flaga3)
                                                {
                                                    bufferToSend1.AddRange(Encoding.ASCII.GetBytes("ACK"));
                                                    bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[0]));
                                                    bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[idxOfSlots1.Count - 1]));
                                                    bufferToSend1.AddRange(BitConverter.GetBytes(cab.Value));

                                                    socket.BeginSend(bufferToSend1.ToArray(), 0, bufferToSend1.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                    bufferToSend1.Clear();
                                                    flaga3 = false;
                                                }
                                            }




                                        }
                                        catch (Exception exep) { Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "Could not reestablish connection between " + source_add.ToString() + " and " + dest_add.ToString()); }


                                        break;
                                    }

                                }
                                if (i >= subnetwork.CC.Connections.Count() - 1) { flaga = false; flaga2 = true; }
                                if (flaga2) { break; }
                            }

                        }
                        else
                        {
                            foreach (Cable c in subnetwork.RC.cables)
                            {
                                if (c.Node1.Equals(dyingNode) || c.Node2.Equals(dyingNode))
                                { c.stateOfCable = false; }
                            }
                        }
                    }
                }

                //wyjscie z funkcji
                return;
            }
            state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, ReadBytes));
            var message = state.sb.ToString().Split(' ');
            if(message[0].Equals("CC-callin"))
            {
                IPAddress ip = IPAddress.Parse(message[1]);
                subnetwork.CC.IPfromSocket.Add(handler, ip);
                subnetwork.CC.SocketfromIP.Add(ip, handler);



                subnetwork.RC.nodesToAlgorithm.Add(IPAddress.Parse(message[1]));
                List<byte> bufferLRM = new List<byte>();
                bufferLRM.AddRange(Encoding.ASCII.GetBytes(message[2]));
                /* for(int j=0; j<bufferLRM.Count;j++)
                 {
                     Console.Write(bufferLRM[j] + " ");

                 }*/
               // Console.WriteLine();
                /*  ushort port1 = (ushort)((bufferLRM[1] << 8) + bufferLRM[0]);
                  Console.WriteLine(port1);
                  Console.WriteLine(bufferLRM.Count);*/
                byte[] buffer = new byte[16];
                int i = 0;
                while (i < bufferLRM.Count)
                {
                    buffer = bufferLRM.GetRange(i, 16).ToArray();
                    ushort port = (ushort)((buffer[1] << 8) + buffer[0]);
                   // Console.WriteLine(port);
                    LinkResourceManager LRM = LinkResourceManager.returnLRM(buffer);
                    i += 16;
                    //Console.WriteLine("Port: " + LRM.port);
                    subnetwork.RC.lrms.Add(LRM);
                }
            }
            if(message[0].Equals("SET-CONNECTION"))
            {
                ushort portS = ushort.Parse(message[1]);
                ushort portF = ushort.Parse(message[2]);
                int startSlot = int.Parse(message[3]);
                int finishSlot = int.Parse(message[4]);
                int speed= int.Parse(message[5]);
                int len_from_domain = int.Parse(message[6]);
                ushort innerPortSource = (ushort)(portS + 1);
                ushort innerPortDest = (ushort)(portF + 1);
                ushort sourceInPort = 0;
                ushort sourceOutPort = 0;
                ushort destOutPort = 0;
                ushort destInPort = 0;
                IPAddress source = null;
                IPAddress destination = null;
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "Connection Request Received");
                Console.WriteLine("ports from domain: " + portS + " " + portF);
                Console.WriteLine("Start and last slot: " + startSlot + " " + finishSlot);
                Console.WriteLine("Speed: " + speed);
                Console.WriteLine("Length from domain: " + len_from_domain);

                foreach(var cable in subnetwork.RC.cables)
                {
                    if(cable.port1.Equals(innerPortSource))
                    {
                        source = cable.Node2;
                        sourceInPort = cable.port2;
                    }
                    else if(cable.port2.Equals(innerPortSource))
                    {
                        source = cable.Node1;
                        sourceInPort = cable.port1;
                    }
                    if (cable.port1.Equals(innerPortDest))
                    {
                        destination = cable.Node2;
                        destOutPort = cable.port2;
                    }
                    else if (cable.port2.Equals(innerPortDest))
                    {
                        destination = cable.Node1;
                        destOutPort=cable.port1;
                    }
                }

                RoutingResult routingResult=subnetwork.RC.SubentDijkstraAlgorithm(source, destination, subnetwork.RC.cables, subnetwork.RC.lrms, speed, startSlot, finishSlot, len_from_domain);
                //

                //Console.WriteLine("We are here");
                subnetwork.CC.Connections.Add(routingResult);
                //Console.WriteLine("Why are you null");
                //Console.WriteLine("Path:");
                //foreach (IPAddress ass in routingResult.Path)
                //{
                //    Console.WriteLine(ass.ToString());
                //}
                //
                foreach(var node in routingResult.Path)
                {
                    //Console.WriteLine("Node: "+node.ToString());
                    Cable cable = findCableBetweenNodes(node, destination, subnetwork.RC.cables);
                    //Console.WriteLine(cable.Node1 + "\t" +cable.Node2 + "\t" +cable.port1 + "\t" +cable.port2);
                    //Console.WriteLine(destination);
                    
                    if(!(cable.Node1==null || cable.Node2==null))
                    {
                        if(cable.Node1.Equals(destination))
                        {
                            destInPort = cable.port1;
                            break;
                        }
                        if (cable.Node2.Equals(destination))
                        {
                            destInPort = cable.port2;
                            break;
                        }
                    }
                }

                //Console.WriteLine("We are here2");
                List<byte> bufferToSend = new List<byte>();
                int ct = 0;
                Socket destSocket = subnetwork.CC.SocketfromIP[destination];
                
               
                bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                bufferToSend.AddRange(BitConverter.GetBytes(startSlot));
                bufferToSend.AddRange(BitConverter.GetBytes(finishSlot));
                bufferToSend.AddRange(BitConverter.GetBytes(destOutPort));
                bufferToSend.AddRange(BitConverter.GetBytes(destInPort));
                destSocket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
        new AsyncCallback(SendCallBack), destSocket);
                bufferToSend.Clear();
                foreach (var cab in routingResult.nodeAndPortsOut)
                {
                    
                    if(cab.Key.Equals(source))
                    {
                        Socket socket1 = subnetwork.CC.SocketfromIP[cab.Key];
                        sourceOutPort = cab.Value;
                        bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                        bufferToSend.AddRange(BitConverter.GetBytes(startSlot));
                        bufferToSend.AddRange(BitConverter.GetBytes(finishSlot));
                        bufferToSend.AddRange(BitConverter.GetBytes(sourceOutPort));
                        bufferToSend.AddRange(BitConverter.GetBytes(sourceInPort));
                        socket1.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                new AsyncCallback(SendCallBack), socket1);
                        bufferToSend.Clear();
                        continue;
                    }
                    bool flaga = false;
                    Socket socket = subnetwork.CC.SocketfromIP[cab.Key];
                    Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                    foreach (var cab1 in routingResult.nodeAndPortsIn)
                    {
                        if (cab1.Key.Equals(cab.Key))
                        {
                            Console.WriteLine("Port in: " + cab1.Value);
                            bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                            bufferToSend.AddRange(BitConverter.GetBytes(startSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(finishSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                            socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                    new AsyncCallback(SendCallBack), socket);
                            bufferToSend.Clear();
                            flaga = true;
                            break;
                        }
                    }
                    
                }
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "Send");
            }


            if (message[0].Equals("REL-CONNECTION"))
            {
                ushort portS = ushort.Parse(message[1]);
                ushort portF = ushort.Parse(message[2]);
                int startSlot = int.Parse(message[3]);
                int finishSlot = int.Parse(message[4]);
                int speed = int.Parse(message[5]);
                int len_from_domain = int.Parse(message[6]);
                ushort innerPortSource = (ushort)(portS + 1);
                ushort innerPortDest = (ushort)(portF + 1);
                ushort sourceInPort = 0;
                ushort sourceOutPort = 0;
                ushort destOutPort = 0;
                ushort destInPort = 0;
                IPAddress source = null;
                IPAddress destination = null;
                //Console.WriteLine("ports from domain: " + portS + " " + portF);
                //Console.WriteLine("Start and last slot: " + startSlot + " " + finishSlot);
                //Console.WriteLine("Speed: " + speed);
                //Console.WriteLine("Length from domain: " + len_from_domain);

                foreach (var cable in subnetwork.RC.cables)
                {
                    if (cable.port1.Equals(innerPortSource))
                    {
                        source = cable.Node2;
                        sourceInPort = cable.port2;
                    }
                    else if (cable.port2.Equals(innerPortSource))
                    {
                        source = cable.Node1;
                        sourceInPort = cable.port1;
                    }
                    if (cable.port1.Equals(innerPortDest))
                    {
                        destination = cable.Node2;
                        destOutPort = cable.port2;
                    }
                    else if (cable.port2.Equals(innerPortDest))
                    {
                        destination = cable.Node1;
                        destOutPort = cable.port1;
                    }
                }
                RoutingResult routingResult = new RoutingResult();
                //RoutingResult routingResult = subnetwork.RC.SubentDijkstraAlgorithm(source, destination, subnetwork.RC.cables, subnetwork.RC.lrms, speed, startSlot, finishSlot, len_from_domain);
                foreach(RoutingResult routingres in subnetwork.CC.Connections)
                {
                    if (routingres.Path[0].Equals(source) && routingres.Path[routingres.Path.Count - 1].Equals(destination) && routingres.lastSlot.Equals(finishSlot))
                        routingResult = routingres;
                }
                //if (routingResult == null) { }
                //subnetwork.CC.Connections.Add(routingResult);
                

                foreach (var node in routingResult.Path)
                {
                    Cable cable = findCableBetweenNodes(node, destination, subnetwork.RC.cables);
                    if (!(cable.Node1==null || cable.Node2==null))
                    {
                        if (cable.Node1.Equals(destination))
                        {
                            destInPort = cable.port1;
                            break;
                        }
                        if (cable.Node2.Equals(destination))
                        {
                            destInPort = cable.port2;
                            break;
                        }
                    }
                }

                foreach (IPAddress ipadd in routingResult.Path)
                {
                    if (routingResult.nodeAndPortsOut.ContainsKey(ipadd))
                    {
                        ushort portout = routingResult.nodeAndPortsOut[ipadd];

                        foreach (LinkResourceManager l in subnetwork.RC.lrms)
                        {
                            if (l.IPofNode.Equals(ipadd) && l.port.Equals(portout))
                            {
                                for (int bb = routingResult.startSlot; bb <= routingResult.lastSlot; bb++)
                                { l.slots[bb] = true; }
                            }
                        }
                    }
                }


                List<byte> bufferToSend = new List<byte>();
                int ct = 0;
                Socket destSocket = subnetwork.CC.SocketfromIP[destination];


                bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                bufferToSend.AddRange(BitConverter.GetBytes(startSlot));
                bufferToSend.AddRange(BitConverter.GetBytes(finishSlot));
                bufferToSend.AddRange(BitConverter.GetBytes(destOutPort));
                bufferToSend.AddRange(BitConverter.GetBytes(destInPort));
                destSocket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
        new AsyncCallback(SendCallBack), destSocket);
                bufferToSend.Clear();
                foreach (var cab in routingResult.nodeAndPortsOut)
                {

                    if (cab.Key.Equals(source))
                    {
                        Socket socket1 = subnetwork.CC.SocketfromIP[cab.Key];
                        sourceOutPort = cab.Value;
                        bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                        bufferToSend.AddRange(BitConverter.GetBytes(startSlot));
                        bufferToSend.AddRange(BitConverter.GetBytes(finishSlot));
                        bufferToSend.AddRange(BitConverter.GetBytes(sourceOutPort));
                        bufferToSend.AddRange(BitConverter.GetBytes(sourceInPort));
                        socket1.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                new AsyncCallback(SendCallBack), socket1);
                        bufferToSend.Clear();
                        continue;
                    }
                    bool flaga = false;
                    Socket socket = subnetwork.CC.SocketfromIP[cab.Key];
                   // Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                    foreach (var cab1 in routingResult.nodeAndPortsIn)
                    {
                        if (cab1.Key.Equals(cab.Key))
                        {
                            //Console.WriteLine("Port in: " + cab1.Value);
                            bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                            bufferToSend.AddRange(BitConverter.GetBytes(startSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(finishSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                            socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                    new AsyncCallback(SendCallBack), socket);
                            bufferToSend.Clear();
                            flaga = true;
                            break;
                        }
                    }

                }

                subnetwork.CC.Connections.Remove(routingResult);
                //Console.WriteLine("Send");
            }







            state.sb.Clear();
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallBack), state);
        }
        public static void WaitForData()// dane które przyjdą na adres 10.0.0.4 wiadomo że to będą styki czyli trzeba tylko ->znaleźć styk-> zmienić port i odesłać do chmury
        {
            while(true)
            {
                byte[] buffer = new byte[128];
                subnetwork.subClientToCloud.Receive(buffer);
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "I received data");
                DataStream dataStream = DataStream.toData(buffer);
                foreach(var inter in subnetwork.interfaces)
                {
                    if(inter.port1.Equals(dataStream.currentPort))
                    {
                        dataStream.currentPort = inter.port2;
                        break;
                    }
                    if (inter.port2.Equals(dataStream.currentPort))
                    {
                        dataStream.currentPort = inter.port1;
                        break;
                    }
                }
                subnetwork.subClientToCloud.Send(dataStream.toBytes());
            }
        }
        // styki można utworzyć przy zgłaszaniu się do chmury tej podsieci: wiemy że port po jednej stronie to x a po drugiej to x+1, z portów które zwróciło, szukamy gdzie jest różnica w portach o 1
        public static void SendCallBack(IAsyncResult ar)
        {
            try
            {
                Socket handler = (Socket)ar.AsyncState;

                int bytesSent = handler.EndSend(ar);


            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        public static Cable findCableBetweenNodes(IPAddress ip1, IPAddress ip2, List<Cable> cables)
        {
            Cable cable = new Cable();
            for (int i = 0; i < cables.Count; i++)
            {
                if ((cables[i].Node1.Equals(ip1) && cables[i].Node2.Equals(ip2) || (cables[i].Node2.Equals(ip1) && cables[i].Node1.Equals(ip2))))
                {
                    cable = cables[i];
                    break;
                }
            }
            return cable;
        }
    }
}
