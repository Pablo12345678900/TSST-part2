﻿using System.Collections.Generic;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using System.Linq;
using Tools;
using System.Globalization;
using static Tools.RoutingController;
/// <summary>
/// 
/// </summary>

namespace DomainApp
{
    public class StateObject
    {
        // Client  socket.  
        public Socket workSocket = null;

        // Size of receive buffer.  
        public const int BufferSize = 128;

        // Receive buffer.  
        public byte[] buffer = new byte[BufferSize];

        // Received data string.  
        public StringBuilder sb = new StringBuilder();
    }
    class Program
    {
        
        public static Domain domain=new Domain();
        public static RoutingResult r = new RoutingResult();

        static void Main(string[] args)
        {
            try
            {
                domain.readinfo(args[0]);
                domain.NCC.directory = args[1];
            }
            catch(Exception e)
            {

            }
            Console.WriteLine(domain.port);
            
            domain.domainServer.Bind(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.port));
            
            domain.domainServer.Listen(50);
            try
                {
                domain.domainClient.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.secondDomainPort));
            }
            catch(Exception e)
            {
                Console.WriteLine("Retrying...");
                domain.domainClient.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.secondDomainPort));
            }
            // Thread thread = new Thread(connectWithSecondDomain);
            //thread.Start();
            //   domain.secondDomainSocket.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.secondDomainPort));

            while (true)
            {
                domain.domainDone.Reset();
                domain.domainServer.BeginAccept(new AsyncCallback(AcceptCallBack), domain.domainServer);
                domain.domainDone.WaitOne();
            }
           
           // Thread2.Start();

        }
        public static void connectWithSecondDomain()
        {

            try
            {
                domain.domainClient.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.secondDomainPort));
            }
            catch(Exception e)
            {
                Console.WriteLine("Domain unreachable, trying reconnecting...");
                connectWithSecondDomain();
            }
            domain.domainClient.Send(Encoding.ASCII.GetBytes("Domain-callin " + IPAddress.Parse("127.0.0.1")));
            while(true)
            {
                byte[] buffer = new byte[128];
                int readBytes = 0;
                readBytes=domain.domainClient.Receive(buffer);
                StringBuilder sb = new StringBuilder();
                sb.Append(Encoding.ASCII.GetString(buffer, 0, readBytes));
                var message = sb.ToString().Split(' ');
                if(message[0].Equals("RC-giveDomainPoint"))
                {
                    IPAddress source = IPAddress.Parse(message[1]);
                    IPAddress destination = IPAddress.Parse(message[2]);
                    int speed = int.Parse(message[3]);
                    StreamReader streamReader = new StreamReader("domainPoints.txt");
                    IPAddress borderAddress = null;
                    string line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        if ((line.Split(' ')[0].Equals(message[1]) && line.Split(' ')[1].Equals(message[2])) || (line.Split(' ')[0].Equals(message[2]) && line.Split(' ')[1].Equals(message[1])))
                        {
                            borderAddress = IPAddress.Parse(line.Split(' ')[2]);
                            break;
                        }
                            
                    }

                    domain.domainClient.Send(Encoding.ASCII.GetBytes("RC-SecondDomainTopology " + borderAddress.ToString() + " " + source.ToString() + " "+ speed + " " + destination.ToString()));
                }
                
            }
            

        }
      
        public static void AcceptCallBack(IAsyncResult asyncResult)
        {
            domain.domainDone.Set();
            Socket listener = (Socket)asyncResult.AsyncState;
            Socket handler = listener.EndAccept(asyncResult);
            StateObject stateObject = new StateObject();
            stateObject.workSocket = handler;

            handler.BeginReceive(stateObject.buffer, 0, stateObject.buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallBack), stateObject);
            //Array.Clear(stateObject.buffer, 0, stateObject.buffer.Length);

        }
        public static void ReceiveCallBack(IAsyncResult asyncResult)
        {
            StateObject state = (StateObject)asyncResult.AsyncState;
            Socket handler = state.workSocket; //socket of client
            
            int ReadBytes;
            try
            {
                ReadBytes = handler.EndReceive(asyncResult);

            }
            catch (Exception e)
            {
                if (domain.CC.IPfromSocket.ContainsKey(handler))
                {


                    IPAddress dyingNode = domain.CC.IPfromSocket[handler]; // router wysyła też swoje LRMy więc trzeba je dodać
                    Console.WriteLine("[" + DateTime.UtcNow.ToString("HH: mm:ss.fff",
                                            System.Globalization.CultureInfo.InvariantCulture) + "] " + "Node: " + dyingNode.ToString() + " died [*].");
                    int index = -1;
                    for (int i = 0; i < domain.RC.nodesToAlgorithm.Count(); i++)
                    {
                        if (domain.RC.nodesToAlgorithm[i].Equals(dyingNode))
                        {
                            index = i;
                            break;
                        }
                    }
                    if (index >= 0)
                    {
                        //usuwamy martwy node z listy
                        domain.RC.nodesToAlgorithm.RemoveAt(index);
                        //usuwamy lrmy w ktorych jest martwy node
                        bool flaga = true;
                        /*while (flaga)
                        {
                            index = -1;
                            for (int k = 0; k < domain.RC.lrms.Count(); k++)
                            {
                                if (k == domain.RC.lrms.Count() - 1)
                                {
                                    flaga = false;
                                }
                                if (domain.RC.lrms[k].IPofNode.Equals(dyingNode))
                                {
                                    index = k;
                                    break;
                                }
                            }
                            if (index >= 0) { domain.RC.lrms.RemoveAt(index); }

                        }*/
                        //wylaczamy kable
                        foreach (Cable c in domain.RC.cables)
                        {
                            if (c.Node1.Equals(dyingNode) || c.Node2.Equals(dyingNode))
                            { c.stateOfCable = false; }
                        }

                        //sprawdzamy czy przez martwy node przechodzily polaczenia, jesli tak musimy je znow wyznaczyc
                        //Console.WriteLine("Checkpoint 56");

                        IPAddress source_add = IPAddress.Parse("0.0.0.0");
                        IPAddress dest_add = IPAddress.Parse("0.0.0.0");
                        int speed;

                        if (domain.CC.Connections.Count > 0)
                        {
                            List<RoutingResult> new_connections = new List<RoutingResult>();

                            bool flaga2 = false;

                            //Console.WriteLine("Checkpoint 2");

                            flaga2 = false;
                            foreach (RoutingResult con in domain.CC.Connections)
                            {
                                if (con.Path.Contains(dyingNode)) { 

                                    source_add = con.Path[0];
                                        dest_add = con.Path[con.Path.Count() - 1];
                                        speed = con.speed;
                                      //  Console.WriteLine("Source: " + source_add + " destination: " + dest_add);

                                        //Console.WriteLine("Checkpoint 44");
                                        ushort portOfSubSource = 0;
                                        ushort portOfSubDest = 0;
                                        bool ifSubnet = false;
                                       
                                        foreach (var node in con.networkNodes)
                                        {
                                            if (node.ipadd.Equals(domain.RC.ipOfSubnet) && domain.RC.ipOfSubnet != null)
                                            {
                                                ifSubnet = true;
                                                break;
                                            }

                                        }
                                        //Console.WriteLine("Checkpoint 66");
                                        if (ifSubnet)
                                        {
                                            Cable cable1 = null;
                                            Console.WriteLine("Traversing a subnetwork");
                                            foreach (var node in con.networkNodes)
                                            {
                                                if (node.ipadd.Equals(source_add))
                                                    continue;
                                                //Console.WriteLine("Node: " + node.ipadd + " Predecessory: " + node.predecessor.ipadd);
                                                if (node.ipadd.Equals(domain.RC.ipOfSubnet))
                                                {
                                                    cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                                    // cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                                    if (cable1.Node1.Equals(node.ipadd))
                                                    {
                                                        portOfSubSource = cable1.port1;
                                                    }
                                                    else if (cable1.Node2.Equals(node.ipadd))
                                                    {
                                                        portOfSubSource = cable1.port2;
                                                    }
                                                }
                                                if (node.predecessor.ipadd.Equals(domain.RC.ipOfSubnet))
                                                {
                                                    cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                                    if (cable1.Node1.Equals(node.predecessor.ipadd))
                                                    {
                                                        portOfSubDest = cable1.port1;
                                                    }
                                                    else if (cable1.Node2.Equals(node.predecessor.ipadd))
                                                    {
                                                        portOfSubDest = cable1.port2;
                                                    }
                                                }
                                            }
                                            Socket socket1 = domain.CC.SocketfromIP[domain.RC.ipOfSubnet];
                                            List<byte> bufferForSubnetwork = new List<byte>();
                                            // Cable cable=findCableBetweenNodes(domain.RC.ipOfSubnet, )
                                            bufferForSubnetwork.AddRange(Encoding.ASCII.GetBytes("REL-CONNECTION " + portOfSubSource + " " + portOfSubDest + " " + con.startSlot + " " + con.lastSlot + " " + con.speed + " " + con.lengthOfGivenDomain));
                                            domain.socketToSub.Send(bufferForSubnetwork.ToArray());
                                            Console.WriteLine("Send to subnetwork rel-connection");
                                        }

                                        //Console.WriteLine("Checkpoint 89");


                                        List<int> idxOfSlots = new List<int>();
                                        for (int j = 0; j < 10; j++)
                                        {
                                            if (con.slots[j])
                                            {
                                                idxOfSlots.Add(j);

                                            }
                                        }

                                        //Console.WriteLine("Checkpoint pre REL");
                                        List<byte> bufferToSend = new List<byte>();
                                        int ct = 0;
                                        foreach (var cab in con.nodeAndPortsOut)
                                        {
                                            if (!cab.Key.Equals(dyingNode))
                                            {
                                                bool flaga1 = false;
                                                Socket socket = domain.CC.SocketfromIP[cab.Key];
                                               // Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                                                foreach (var cab1 in con.nodeAndPortsIn)
                                                {
                                                    if (cab1.Key.Equals(cab.Key))
                                                    {
                                                        bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[0]));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[idxOfSlots.Count - 1]));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                                                        bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                                                        socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                        bufferToSend.Clear();
                                                        flaga1 = true;
                                                        break;
                                                    }
                                                }
                                                if (!flaga1)
                                                {
                                                    bufferToSend.AddRange(Encoding.ASCII.GetBytes("REL"));
                                                    bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[0]));
                                                    bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[idxOfSlots.Count - 1]));
                                                    bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));

                                                    socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                    bufferToSend.Clear();
                                                    flaga1 = false;
                                                }
                                            }
                                        }


                                        foreach (Cable c in domain.RC.cables)
                                        {
                                            if (c.Node1.Equals(dyingNode) || c.Node2.Equals(dyingNode))
                                            { c.stateOfCable = false; }
                                        }
                                        //
                                        // Console.WriteLine("Checkpoint pre LRM");
                                        //czyszczenie lrmow w RC
                                        foreach (IPAddress ipadd in con.Path)
                                        {
                                            if (con.nodeAndPortsOut.ContainsKey(ipadd))
                                            {
                                                ushort portout = con.nodeAndPortsOut[ipadd];

                                                foreach (LinkResourceManager l in domain.RC.lrms)
                                                {
                                                    if (l.IPofNode.Equals(ipadd) && l.port.Equals(portout))
                                                    {
                                                        for (int bb = con.startSlot; bb <= con.lastSlot; bb++)
                                                        { l.slots[bb] = true; }
                                                    }
                                                }
                                            }
                                        }
                                        int startslot = con.startSlot;
                                        int endslot = con.lastSlot;
                                        int dlength = con.lengthOfGivenDomain;
                                        //domain.CC.Connections.RemoveAt(i);
                                        flaga2 = true;
                                        ////wysylanie na nowo
                                        Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                            System.Globalization.CultureInfo.InvariantCulture) + "] " + "Configurations cleared, recalculating path...");
                                        try
                                        {
                                        Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                       System.Globalization.CultureInfo.InvariantCulture) + "] " + "Route table query between: "+source_add.ToString()+" and "+dest_add.ToString());

                                        RoutingResult routingResult = domain.RC.SubentDijkstraAlgorithm(source_add, dest_add, domain.RC.cables, domain.RC.lrms, speed, startslot, endslot, dlength);

                                            new_connections.Add(routingResult);
                                            //wymuszenie exception dla pustego
                                            if (routingResult.Equals(null)) { }
                                            ushort portOfSubSource1 = 0;
                                            ushort portOfSubDest1 = 0;
                                            bool ifSubnet1 = false;
                                            foreach (var node in routingResult.Path)
                                            {
                                                if (node.Equals(domain.RC.ipOfSubnet) && domain.RC.ipOfSubnet != null)
                                                {
                                                    ifSubnet1 = true;
                                                    break;
                                                }

                                            }
                                            if (ifSubnet1)
                                            {
                                                Cable cable1 = null;
                                                foreach (var node in routingResult.networkNodes)
                                                {
                                                    if (node.ipadd.Equals(source_add))
                                                        continue;
                                                   // Console.WriteLine("Node: " + node.ipadd + " Predecessory: " + node.predecessor.ipadd);
                                                    if (node.ipadd.Equals(domain.RC.ipOfSubnet))
                                                    {
                                                        cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                                        // cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                                        if (cable1.Node1.Equals(node.ipadd))
                                                        {
                                                            portOfSubSource1 = cable1.port1;
                                                        }
                                                        else if (cable1.Node2.Equals(node.ipadd))
                                                        {
                                                            portOfSubSource1 = cable1.port2;
                                                        }
                                                    }
                                                    if (node.predecessor.ipadd.Equals(domain.RC.ipOfSubnet))
                                                    {
                                                        cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                                        if (cable1.Node1.Equals(node.predecessor.ipadd))
                                                        {
                                                            portOfSubDest1 = cable1.port1;
                                                        }
                                                        else if (cable1.Node2.Equals(node.predecessor.ipadd))
                                                        {
                                                            portOfSubDest1 = cable1.port2;
                                                        }
                                                    }
                                                }

                                                Socket socket1 = domain.CC.SocketfromIP[domain.RC.ipOfSubnet];
                                                List<byte> bufferForSubnetwork = new List<byte>();
                                                // Cable cable=findCableBetweenNodes(domain.RC.ipOfSubnet, )
                                                bufferForSubnetwork.AddRange(Encoding.ASCII.GetBytes("SET-CONNECTION " + portOfSubSource1 + " " + portOfSubDest1 + " " + startslot + " " + endslot + " " + speed + " " + routingResult.lengthOfGivenDomain));
                                                domain.socketToSub.Send(bufferForSubnetwork.ToArray());
                                            }

                                                List<int> idxOfSlots1 = new List<int>();
                                            for (int a = 0; a < 10; a++)
                                            {
                                                if (routingResult.slots[a])
                                                {
                                                    idxOfSlots1.Add(a);
                                                }
                                            }
                                            foreach (var node in routingResult.Path)
                                            {
                                                Console.WriteLine("Chosen node: " + node.ToString());
                                            }
                                            List<byte> bufferToSend1 = new List<byte>();
                                            foreach (var cab in routingResult.nodeAndPortsOut)
                                            {
                                                bool flaga3 = false;
                                                Socket socket = domain.CC.SocketfromIP[cab.Key];
                                                Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                                                foreach (var cab1 in routingResult.nodeAndPortsIn)
                                                {
                                                    if (cab1.Key.Equals(cab.Key))
                                                    {
                                                        Console.WriteLine("Port in: " + cab1.Value);
                                                        bufferToSend1.AddRange(Encoding.ASCII.GetBytes("ACK"));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[0]));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[idxOfSlots1.Count - 1]));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(cab.Value));
                                                        bufferToSend1.AddRange(BitConverter.GetBytes(cab1.Value));
                                                        socket.BeginSend(bufferToSend1.ToArray(), 0, bufferToSend1.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                        bufferToSend1.Clear();
                                                        flaga3 = true;
                                                        break;
                                                    }
                                                }
                                                if (!flaga3)
                                                {
                                                    bufferToSend1.AddRange(Encoding.ASCII.GetBytes("ACK"));
                                                    bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[0]));
                                                    bufferToSend1.AddRange(BitConverter.GetBytes(idxOfSlots1[idxOfSlots1.Count - 1]));
                                                    bufferToSend1.AddRange(BitConverter.GetBytes(cab.Value));

                                                    socket.BeginSend(bufferToSend1.ToArray(), 0, bufferToSend1.ToArray().Length, 0,
                                                new AsyncCallback(SendCallBack), socket);
                                                    bufferToSend1.Clear();
                                                    flaga3 = false;
                                                }
                                            }


                                            Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                            System.Globalization.CultureInfo.InvariantCulture) + "] " + "Connection reestablished between " + source_add.ToString() + " and " + dest_add.ToString());
                                        


                                        }
                                        catch (Exception exep) { Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                            System.Globalization.CultureInfo.InvariantCulture) + "] " + "Could not reestablish connection between " + source_add.ToString() + " and " + dest_add.ToString()); }


                                      
                                    }

                                
                                //if (i >= domain.CC.Connections.Count() - 1) { flaga = false; flaga2 = true; }
                                //if (flaga2) { break; }
                            }

                            bool flagax = true;
                            int counter = 0;
                            while (flagax)
                            {
                                if (domain.CC.Connections[counter].Path.Contains(dyingNode))
                                {
                                    domain.CC.Connections.RemoveAt(counter);
                                    counter = 0;
                                }
                                else { counter++; }
                                if (counter >= domain.CC.Connections.Count) { flagax = false; }
                            }
                            foreach (RoutingResult con in new_connections)
                            {
                            
                                domain.CC.Connections.Add(con);
                            }

                        }
                        else
                        {
                            foreach (Cable c in domain.RC.cables)
                            {
                                if (c.Node1.Equals(dyingNode) || c.Node2.Equals(dyingNode))
                                { c.stateOfCable = false; }
                            }
                        }
                    }
                }
                //Console.WriteLine("Exit checkpoint");
                //wyjscie z funkcji
                return;
            }

            state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, ReadBytes));
            var message = state.sb.ToString().Split(' ');
            // first message must be send to get information about connected socket: First Message <Ip address>
            if (message[0].Equals("NCC-GET")) // żądanie hosta na połączenie
            {
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH: mm:ss.fff",
                                    CultureInfo.InvariantCulture) + "] " + "NCC: CallRequest received-> source: " + message[1] + " destination: "+ message[2] + " with demanded speed: " + message[3]);
                String source = message[1];
                String destination = message[2];
                int speed = int.Parse(message[3]);
                
              //  Console.WriteLine("Speed " + speed);
                Console.WriteLine("NCC: Directory Request for: " + source);
                IPAddress sourceAddress = domain.NCC.DirectoryRequest(source);
                Console.WriteLine("NCC: Directory Request for: " + destination);
                IPAddress destAddress = domain.NCC.DirectoryRequest(destination);
                bool flag = false;
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "NCC: Policy request for source: " + source + " and " + destination);
                flag = domain.NCC.PolicyRequest(source, destination);
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "NCC: Everything with policy is ok");
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "NCC: Connection Request to CC with parametres: " + sourceAddress + ", " + destAddress + ", "+speed ); //dorobić argumenty

               // Console.WriteLine("Can we send from " + source + " " + destination+ "? ->" + flag);
                ushort portOfSubSource = 0;
                ushort portOfSubDest = 0;
                bool ifSubnet = false;
                if (sourceAddress != null && destAddress != null)
                { //RC w swoim pliku ma odległość przy danym source i destination więc to też do zrobienia
                    Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "NCC: Connection Request to CC with parametres: " + sourceAddress + ", " + destAddress + ", " + speed); //dorobić argumenty

                    Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                           CultureInfo.InvariantCulture) + "] " + "CC: RouteTableQuery request between "+source+" and "+destination + " with demanded speed: "+speed);
                    RoutingResult routingResult = domain.RC.DijkstraAlgorithm(sourceAddress, destAddress, domain.RC.cables, domain.RC.lrms, speed); // prototyp funkcji Dijkstry
                    domain.CC.Connections.Add(routingResult);
                    // Console.WriteLine("Connectios: " + domain.CC.Connections.Count);

                    Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                           CultureInfo.InvariantCulture) + "] " + "RC: RouteTableQuery response:\n 1) start slot: " + routingResult.startSlot + "\n 2) last slot: "+routingResult.lastSlot +
                           "\n 3)List of nodes and their used ports: ");
                    foreach(var cable in routingResult.nodeAndPortsOut)
                    {
                        Console.Write("Node: " + cable.Key + " port out: " + cable.Value + " port in: ");
                        foreach(var cab1 in routingResult.nodeAndPortsIn)
                        {
                            if(cab1.Key.Equals(cable.Key))
                            {
                                Console.WriteLine(cab1.Value);
                            }
                        }
                    }
                    foreach (var node in routingResult.Path)
                    {
                        if (node.Equals(domain.RC.ipOfSubnet) && domain.RC.ipOfSubnet!=null)
                        {
                            ifSubnet = true;
                            break;
                        }

                    }
                    if (ifSubnet)
                    {
                        Cable cable1 = null;
                        foreach (var node in routingResult.networkNodes)
                        {
                            if (node.ipadd.Equals(sourceAddress))
                                continue;
                            //Console.WriteLine("Node: " + node.ipadd + " Predecessory: " + node.predecessor.ipadd);
                            if (node.ipadd.Equals(domain.RC.ipOfSubnet))
                            {
                                cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                // cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                if (cable1.Node1.Equals(node.ipadd))
                                {
                                    portOfSubSource = cable1.port1;
                                }
                                else if (cable1.Node2.Equals(node.ipadd))
                                {
                                    portOfSubSource = cable1.port2;
                                }
                            }
                            if (node.predecessor.ipadd.Equals(domain.RC.ipOfSubnet))
                            {
                                cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                                if (cable1.Node1.Equals(node.predecessor.ipadd))
                                {
                                    portOfSubDest = cable1.port1;
                                }
                                else if (cable1.Node2.Equals(node.predecessor.ipadd))
                                {
                                    portOfSubDest = cable1.port2;
                                }
                            }
                        }



                        Socket socket1 = domain.CC.SocketfromIP[domain.RC.ipOfSubnet];
                        List<byte> bufferForSubnetwork = new List<byte>();
                        // Cable cable=findCableBetweenNodes(domain.RC.ipOfSubnet, )
                        bufferForSubnetwork.AddRange(Encoding.ASCII.GetBytes("SET-CONNECTION " + portOfSubSource + " " + portOfSubDest + " " + routingResult.startSlot + " " + routingResult.lastSlot + " " + routingResult.speed + " " + routingResult.lengthOfGivenDomain));
                        domain.socketToSub.Send(bufferForSubnetwork.ToArray());
                        Console.WriteLine("[" + DateTime.UtcNow.ToString("HH: mm:ss.fff",
                                         CultureInfo.InvariantCulture) + "] " + "CC: SNPP Link Connection Request to: " +domain.RC.ipOfSubnet.ToString() + " with parametres: " + " port of subnetwork in: " + portOfSubSource + " and port of subnetwork out: " + portOfSubDest + " start slot " +routingResult.startSlot+
                                         " and last slot: "+routingResult.lastSlot);
                    }

                    //  Console.WriteLine("RoutingResult Count: " + routingResult.networkNodes.Count);

                    /////to trzeba poprawic
                    List<int> idxOfSlots = new List<int>();
                    for (int i = 0; i < 10; i++)
                    {
                        if (routingResult.slots[i])
                        {
                            idxOfSlots.Add(i);
                            Console.WriteLine("Index of slot: " + i);
                        }
                    }
                    //foreach (var node in routingResult.Path)
                    //{
                    //    Console.WriteLine("Chosen node: " + node.ToString());
                    //}
                    List<byte> bufferToSend = new List<byte>();
                    int ct = 0;
                    foreach (var cab in routingResult.nodeAndPortsOut)
                    {
                        bool flaga = false;
                        Socket socket = domain.CC.SocketfromIP[cab.Key];
                        Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                        foreach (var cab1 in routingResult.nodeAndPortsIn)
                        {
                            if (cab1.Key.Equals(cab.Key))
                            {
                                Console.WriteLine("Port in: " + cab1.Value);
                                bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                                bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[0]));
                                bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[idxOfSlots.Count - 1]));
                                bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                                bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                                socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                        new AsyncCallback(SendCallBack), socket);
                                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH: mm:ss.fff",
                                        CultureInfo.InvariantCulture) + "] " + "CC: SNPP Link Connection Request to: " + cab.Key +
                                        " with parametres: " + " port in: " + cab1.Value + " and port  out: " + cab.Value + " with slots from " + idxOfSlots[0] + " to " + idxOfSlots[idxOfSlots.Count-1]);
                                bufferToSend.Clear();
                                flaga = true;
                                break;
                            }
                        }
                        if (!flaga)
                        {
                            bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                            bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[0]));
                            bufferToSend.AddRange(BitConverter.GetBytes(idxOfSlots[idxOfSlots.Count - 1]));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));

                            socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                        new AsyncCallback(SendCallBack), socket);
                            Console.WriteLine("Send to host: " + cab.Key + " port");
                            bufferToSend.Clear();
                            flaga = false;
                        }
                    }

                }
                else
                {
                    /*Thread thread = new Thread(connectWithSecondDomain);
                    thread.Start();*/

                    List<byte> buffer = new List<byte>();
                    buffer.AddRange(Encoding.ASCII.GetBytes("RC-giveDomainPoint " + sourceAddress.ToString() + " " + destination + " " + speed));
                    // Socket socket = domain.CC.SocketfromIP[IPAddress.Parse("127.0.0.1")];
                    //socket.BeginSend(buffer.ToArray(),0,buffer.ToArray().Length,0, new AsyncCallback(SendCallBack), socket);

                    //Console.WriteLine("Connected");
                    domain.domainClient.Send(buffer.ToArray());
                    Console.WriteLine("[" + DateTime.UtcNow.ToString("HH: mm:ss.fff",
                                         CultureInfo.InvariantCulture) + "] " + "NCC: CallCoordination between " +source +" and "+ destination);
                    // domain.domainClient.Disconnect(true);
                    //domain.domainClient.Send(buffer.ToArray());
                }
            }
              //  bool ifSubnet = false;
                
                //  Console.WriteLine("RoutingResult Count: " + routingResult.networkNodes.Count);
               
            if (message[0].Equals("RC-giveDomainPoint"))
            {
                //Console.WriteLine("[" + DateTime.UtcNow.ToString("HH: mm:ss.fff",
                //                         CultureInfo.InvariantCulture) + "] " + "NCC: CallCoordination Received");
                IPAddress source = IPAddress.Parse(message[1]);
                String destination = message[2];
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                         CultureInfo.InvariantCulture) + "] " + "NCC: CallCoordination Received for a connection between: "+source.ToString()+" and "+destination);
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                         CultureInfo.InvariantCulture) + "] " + "NCC: Checking in directory...");
                IPAddress destAddress = domain.NCC.DirectoryRequest(destination);
                int speed = int.Parse(message[3]);
                StreamReader streamReader = new StreamReader("domainPoints.txt");
                IPAddress borderAddress = null;
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    if ((IPAddress.Parse(line.Split(' ')[0]).Equals(source) && IPAddress.Parse(line.Split(' ')[1]).Equals(destAddress)) || (IPAddress.Parse(line.Split(' ')[0]).Equals(destAddress) && IPAddress.Parse(line.Split(' ')[1]).Equals(source)))
                    {
                        borderAddress = IPAddress.Parse(line.Split(' ')[2]);
                        Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                         CultureInfo.InvariantCulture) + "] " + "Found border point");
                        break;
                    }

                }
               // domain.domainClient.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.secondDomainPort));
                domain.domainClient.Send(Encoding.ASCII.GetBytes("RC-SecondDomainTopology " + borderAddress.ToString() + " " + source.ToString() + " " + speed + " " + destAddress.ToString()));
               // domain.domainClient.Disconnect(true);
               // Console.WriteLine("Send " + borderAddress.ToString());
            }
            if (message[0].Equals("SET-REST-CONNECTION"))
            {
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "I will set rest connection");
                IPAddress border = IPAddress.Parse(message[1]);
                IPAddress destination = IPAddress.Parse(message[2]);
                int speed = int.Parse(message[3]);
                int startslot = int.Parse(message[4]);
                int lastSlot = int.Parse(message[5]);
                int length_of_prev_domain = int.Parse(message[6]);
                IPAddress source = IPAddress.Parse(message[7]);
                
                RoutingResult result=domain.RC.SubentDijkstraAlgorithm(border, destination, domain.RC.cables, domain.RC.lrms, speed, startslot, lastSlot, length_of_prev_domain);



                bool ifSubnet = false;
                foreach (var node in result.Path)
                {
                    if (node.Equals(domain.RC.ipOfSubnet) && domain.RC.ipOfSubnet != null)
                    {
                        ifSubnet = true;
                        break;
                    }

                }
                ushort portOfSubSource = 0;
                ushort portOfSubDest = 0;
                if (ifSubnet)
                {
                    Cable cable1 = null;
                    foreach (var node in result.networkNodes)
                    {
                        if (node.ipadd.Equals(border))
                            continue;
                        //Console.WriteLine("Node: " + node.ipadd + " Predecessory: " + node.predecessor.ipadd);
                        if (node.ipadd.Equals(domain.RC.ipOfSubnet))
                        {
                            cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                            // cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                            if (cable1.Node1.Equals(node.ipadd))
                            {
                                portOfSubSource = cable1.port1;
                            }
                            else if (cable1.Node2.Equals(node.ipadd))
                            {
                                portOfSubSource = cable1.port2;
                            }
                        }
                        if (node.predecessor.ipadd.Equals(domain.RC.ipOfSubnet))
                        {
                            cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                            if (cable1.Node1.Equals(node.predecessor.ipadd))
                            {
                                portOfSubDest = cable1.port1;
                            }
                            else if (cable1.Node2.Equals(node.predecessor.ipadd))
                            {
                                portOfSubDest = cable1.port2;
                            }
                        }
                    }
                    Socket socket1 = domain.CC.SocketfromIP[domain.RC.ipOfSubnet];
                    List<byte> bufferForSubnetwork = new List<byte>();
                    // Cable cable=findCableBetweenNodes(domain.RC.ipOfSubnet, )
                    bufferForSubnetwork.AddRange(Encoding.ASCII.GetBytes("SET-CONNECTION " + portOfSubSource + " " + portOfSubDest + " " + result.startSlot + " " + result.lastSlot + " " + result.speed + " " + result.lengthOfGivenDomain));
                    domain.socketToSub.Send(bufferForSubnetwork.ToArray());
                    Console.WriteLine("Send to subnetwork");
                }




                domain.CC.Connections.Add(result);
                List<byte> bufferToSend = new List<byte>();
                if (result.lastSlot==lastSlot)
                {
                    foreach (var cab in result.nodeAndPortsOut)
                    {
                        bool flaga = false;
                        Socket socket = domain.CC.SocketfromIP[cab.Key];
                        Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                        
                        foreach (var cab1 in result.nodeAndPortsIn)
                        {
                            if (cab1.Key.Equals(cab.Key))
                            {
                                Console.WriteLine("Port in: " + cab1.Value);
                                bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                                bufferToSend.AddRange(BitConverter.GetBytes(result.startSlot));
                                bufferToSend.AddRange(BitConverter.GetBytes(result.lastSlot));
                                bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                                bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                                socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                        new AsyncCallback(SendCallBack), socket);
                                bufferToSend.Clear();
                                flaga = true;
                                break;
                            }
                        }
                        if (!flaga)
                        {
                            bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                            bufferToSend.AddRange(BitConverter.GetBytes(result.startSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(result.lastSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));

                            socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                        new AsyncCallback(SendCallBack), socket);
                            Console.WriteLine("Send to E-nni: " + cab.Key);
                            bufferToSend.Clear();
                            flaga = false;
                        }
                    }
                    bufferToSend.AddRange(Encoding.ASCII.GetBytes("OK"));
                    domain.domainClient.Send(bufferToSend.ToArray());
                    

                }
                else
                {
                    List<byte> buffer = new List<byte>();
                    buffer.AddRange(Encoding.ASCII.GetBytes("RETRY " + source.ToString() + " " + border.ToString() + " " + speed + " " + result.startSlot + " " + result.lastSlot + " " + result.lengthOfGivenDomain + " " + destination.ToString()));
                    domain.domainClient.Send(buffer.ToArray());               
                }

            }
            if (message[0].Equals("RETRY"))
            {
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "I will RETRY");
                IPAddress source = IPAddress.Parse(message[1]);
                IPAddress border = IPAddress.Parse(message[2]);
                int speed = int.Parse(message[3]);
                int startslot = int.Parse(message[4]);
                int lastSlot = int.Parse(message[5]);
                int length_of_prev_domain = int.Parse(message[6]);
                IPAddress destination = IPAddress.Parse(message[7]);
                RoutingResult result = domain.RC.SubentDijkstraAlgorithm(border, destination, domain.RC.cables, domain.RC.lrms, speed, startslot, lastSlot, length_of_prev_domain);
                List<byte> buffer = new List<byte>();
                buffer.AddRange(Encoding.ASCII.GetBytes("SET-REST-CONNECTION " + border.ToString() + " " + destination.ToString() + " " + speed + " " + result.startSlot + " " + result.lastSlot + " " + result.lengthOfGivenDomain + " " + source.ToString()));
                domain.domainClient.Send(buffer.ToArray());
            }
            if(message[0].Equals("OK"))
            {
                foreach (var cab in r.nodeAndPortsOut)
                {
                    bool flaga = false;
                    Socket socket = domain.CC.SocketfromIP[cab.Key];
                    Console.WriteLine("Adres: " + cab.Key + " port out: " + cab.Value);
                    List<byte> bufferToSend = new List<byte>();
                    foreach (var cab1 in r.nodeAndPortsIn)
                    {
                        if (cab1.Key.Equals(cab.Key))
                        {
                            Console.WriteLine("Port in: " + cab1.Value);
                            bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                            bufferToSend.AddRange(BitConverter.GetBytes(r.startSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(r.lastSlot));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));
                            bufferToSend.AddRange(BitConverter.GetBytes(cab1.Value));
                            socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                    new AsyncCallback(SendCallBack), socket);
                            bufferToSend.Clear();
                            flaga = true;
                            break;
                        }
                    }
                    if (!flaga)
                    {
                        bufferToSend.AddRange(Encoding.ASCII.GetBytes("ACK"));
                        bufferToSend.AddRange(BitConverter.GetBytes(r.startSlot));
                        bufferToSend.AddRange(BitConverter.GetBytes(r.lastSlot));
                        bufferToSend.AddRange(BitConverter.GetBytes(cab.Value));

                        socket.BeginSend(bufferToSend.ToArray(), 0, bufferToSend.ToArray().Length, 0,
                    new AsyncCallback(SendCallBack), socket);
                        Console.WriteLine("Send to Host: " + cab.Key);
                        bufferToSend.Clear();
                        flaga = false;
                    }
                }
            }

            //Domain.NCC.ConnectionRequest(sourceAddress, destAddress, speed);

            if (message[0].Equals("RC-SecondDomainTopology"))
            {
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "RC second domain topology");
                IPAddress borderAddress = IPAddress.Parse(message[1]);
                IPAddress sourceAddress = IPAddress.Parse(message[2]);
                int speed = int.Parse(message[3]);
                IPAddress destinationAddress = IPAddress.Parse(message[4]);
              //  Console.WriteLine("Saved data");
                RoutingResult routing = domain.RC.DijkstraAlgorithm(sourceAddress, borderAddress, domain.RC.cables, domain.RC.lrms, speed);
                r = routing;
                domain.CC.Connections.Add(r);
                bool ifSubnet = false;
                foreach (var node in routing.Path)
                {
                    if (node.Equals(domain.RC.ipOfSubnet) && domain.RC.ipOfSubnet != null)
                    {
                        ifSubnet = true;
                        break;
                    }

                }
                ushort portOfSubSource = 0;
                ushort portOfSubDest = 0;
                if (ifSubnet)
                {
                    Cable cable1 = null;
                    foreach (var node in routing.networkNodes)
                    {
                        if (node.ipadd.Equals(sourceAddress))
                            continue;
                        //Console.WriteLine("Node: " + node.ipadd + " Predecessory: " + node.predecessor.ipadd);
                        if (node.ipadd.Equals(domain.RC.ipOfSubnet))
                        {
                            cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                            // cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                            if (cable1.Node1.Equals(node.ipadd))
                            {
                                portOfSubSource = cable1.port1;
                            }
                            else if (cable1.Node2.Equals(node.ipadd))
                            {
                                portOfSubSource = cable1.port2;
                            }
                        }
                        if (node.predecessor.ipadd.Equals(domain.RC.ipOfSubnet))
                        {
                            cable1 = findCableBetweenNodes(node.ipadd, node.predecessor.ipadd, domain.RC.cables);
                            if (cable1.Node1.Equals(node.predecessor.ipadd))
                            {
                                portOfSubDest = cable1.port1;
                            }
                            else if (cable1.Node2.Equals(node.predecessor.ipadd))
                            {
                                portOfSubDest = cable1.port2;
                            }
                        }
                    }
                    Socket socket1 = domain.CC.SocketfromIP[domain.RC.ipOfSubnet];
                    List<byte> bufferForSubnetwork = new List<byte>();
                    // Cable cable=findCableBetweenNodes(domain.RC.ipOfSubnet, )
                    bufferForSubnetwork.AddRange(Encoding.ASCII.GetBytes("SET-CONNECTION " + portOfSubSource + " " + portOfSubDest + " " + routing.startSlot + " " + routing.lastSlot + " " + routing.speed + " " + routing.lengthOfGivenDomain));
                    domain.socketToSub.Send(bufferForSubnetwork.ToArray());
                    Console.WriteLine("Send to subnetwork");
                }
                    /*List<int> idxOfSlots = new List<int>();
                    for (int i = 0; i < 10; i++)
                    {
                        if (routing.slots[i])
                        {
                            idxOfSlots.Add(i);
                            Console.WriteLine("Index of slot: " + i);
                        }
                    }*/
                    // Socket socket = domain.CC.SocketfromIP[IPAddress.Parse("127.0.0.1")];
                    List<byte> buffer = new List<byte>();
                    buffer.AddRange(Encoding.ASCII.GetBytes("SET-REST-CONNECTION " + borderAddress.ToString() + " " + destinationAddress.ToString() + " " + speed + " " + routing.startSlot + " " + routing.lastSlot + " " + routing.lengthOfGivenDomain + " " + sourceAddress.ToString()));
                    //domain.domainClient.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), domain.secondDomainPort));
                    domain.domainClient.Send(buffer.ToArray());
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                                         CultureInfo.InvariantCulture) + "] " + "Send to second domain that it has to give rest of connection");
                //domain.domainClient.Disconnect(true);
                // socket.BeginSend(buffer.ToArray(), 0, buffer.ToArray().Length, 0, new AsyncCallback(SendCallBack), socket);



            }
           
            if (message[0].Equals("CC-callin"))
            {
                domain.CC.IPfromSocket.Add(handler, IPAddress.Parse(message[1]));
                domain.CC.SocketfromIP.Add(IPAddress.Parse(message[1]), handler); // router wysyła też swoje LRMy więc trzeba je dodać do RC
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "RC: " + IPAddress.Parse(message[1]) + " sent LocalTopology");
                domain.RC.nodesToAlgorithm.Add(IPAddress.Parse(message[1]));
                List<byte> bufferLRM = new List<byte>();
                bufferLRM.AddRange(Encoding.ASCII.GetBytes(message[2]));
               /* for(int j=0; j<bufferLRM.Count;j++)
                {
                    Console.Write(bufferLRM[j] + " ");
                    
                }*/
                //Console.WriteLine();
              /*  ushort port1 = (ushort)((bufferLRM[1] << 8) + bufferLRM[0]);
                Console.WriteLine(port1);
                Console.WriteLine(bufferLRM.Count);*/
                byte[] buffer = new byte[16];
                int i = 0;
                while(i<bufferLRM.Count)
                {
                    buffer = bufferLRM.GetRange(i, 16).ToArray();
                    ushort port = (ushort)((buffer[1] << 8) + buffer[0]);
                    //Console.WriteLine(port);
                    LinkResourceManager LRM = LinkResourceManager.returnLRM(buffer);
                    i += 16;
                    //Console.WriteLine("Port: " +LRM.port);
                    domain.RC.lrms.Add(LRM);
                }
               // Array.Clear(state.buffer, 0, state.buffer.Length);

            }        
            if(message[0].Equals("SUBNETWORK-callin"))
            {
                domain.CC.IPfromSocket.Add(handler, IPAddress.Parse(message[1]));
                domain.CC.SocketfromIP.Add(IPAddress.Parse(message[1]), handler);
                domain.RC.nodesToAlgorithm.Add(IPAddress.Parse(message[1]));
                domain.RC.ipOfSubnet = IPAddress.Parse(message[1]);
                ushort portOfSub = ushort.Parse(message[2]);
                Console.WriteLine("[" + DateTime.UtcNow.ToString("HH:mm:ss.fff",
                            CultureInfo.InvariantCulture) + "] " + "RC: " + IPAddress.Parse(message[1])+" sent LocalTopology");
                List<byte> bufferLRM = new List<byte>();
                domain.socketToSub.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), portOfSub));
                bufferLRM.AddRange(Encoding.ASCII.GetBytes(message[3]));
                byte[] buffer = new byte[16];
                int i = 0;
                while (i < bufferLRM.Count)
                {
                    buffer = bufferLRM.GetRange(i, 16).ToArray();
                    ushort port = (ushort)((buffer[1] << 8) + buffer[0]);
                    //Console.WriteLine("Ports of subnetwork: " + port) ;
                    LinkResourceManager LRM = LinkResourceManager.returnLRM(buffer);
                    i += 16;
                   // Console.WriteLine("Port: " + LRM.port);
                    domain.RC.lrms.Add(LRM);
                }


            }
            state.sb.Clear();
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallBack), state);
        }
        

      

           // zwykła dijkstra, trzeba wrzucić ją w RC i napisać prawidłową
            
           



            public static Cable findCableBetweenNodes(IPAddress ip1,IPAddress ip2, List<Cable> cables)
            {
                Cable cable = null;
                for(int i=0; i<cables.Count;i++)
                {
                    if((cables[i].Node1.Equals(ip1) && cables[i].Node2.Equals(ip2)) || (cables[i].Node2.Equals(ip1) && cables[i].Node1.Equals(ip2)))
                    {
                        cable = cables[i];
                        break;
                    }
                }
                return cable;
            }
            public static LinkResourceManager findLRM(IPAddress ip, ushort port, List<LinkResourceManager> links)
            {
                LinkResourceManager link = null;
                foreach(var l in links)
                {
                    if (l.IPofNode==ip && l.port == port)
                    {
                        link = l;
                        break;
                    }
                        
                }
                return link;
            }
            private static void Send(Socket handler, String data)
            {
                byte[] byteData = Encoding.ASCII.GetBytes(data);

                handler.BeginSend(byteData, 0, byteData.Length, 0,
                    new AsyncCallback(SendCallBack), handler);
            }

            public static void SendCallBack(IAsyncResult ar)
            {
                try
                {
                    Socket handler = (Socket)ar.AsyncState;

                    int bytesSent = handler.EndSend(ar);


                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
        }
}


